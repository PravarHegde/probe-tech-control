import{S as r}from"./Viewer-qmFba4Wv.js";const e="kernelBlurVaryingDeclaration",a="varying vec2 sampleCoord{X};";r.IncludesShadersStore[e]=a;
