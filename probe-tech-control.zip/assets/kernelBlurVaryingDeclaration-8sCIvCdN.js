import{S as e}from"./index-CkQ16Qdh.js";const r="kernelBlurVaryingDeclaration",a="varying vec2 sampleCoord{X};";e.IncludesShadersStore[r]||(e.IncludesShadersStore[r]=a);
